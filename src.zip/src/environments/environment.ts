// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false
};

export const firebase = {
  firebaseConfig : {
    apiKey: "AIzaSyC_GTZw4f5dbQyeo4nEWMQ5OpeZmquG2q4",
    authDomain: "tianguiztli-e2f7f.firebaseapp.com",
    databaseURL: "https://tianguiztli-e2f7f-default-rtdb.firebaseio.com",
    projectId: "tianguiztli-e2f7f",
    storageBucket: "tianguiztli-e2f7f.appspot.com",
    messagingSenderId: "521004238691",
    appId: "1:521004238691:web:79989a6bddbea40ba4f556",
    measurementId: "G-G8JLR1LV6M"
  }
};


/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
