export const environment = {
  production: true
};
export const firebase = {
  firebaseConfig : {
    apiKey: "AIzaSyC_GTZw4f5dbQyeo4nEWMQ5OpeZmquG2q4",
    authDomain: "tianguiztli-e2f7f.firebaseapp.com",
    databaseURL: "https://tianguiztli-e2f7f-default-rtdb.firebaseio.com",
    projectId: "tianguiztli-e2f7f",
    storageBucket: "tianguiztli-e2f7f.appspot.com",
    messagingSenderId: "521004238691",
    appId: "1:521004238691:web:79989a6bddbea40ba4f556",
    measurementId: "G-G8JLR1LV6M"
  }
};